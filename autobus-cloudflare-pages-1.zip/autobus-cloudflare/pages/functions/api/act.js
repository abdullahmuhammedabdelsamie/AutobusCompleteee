import { forward } from '../../_lib/proxy.js';
export async function onRequest(context) { return forward(context.request, context.env); }
