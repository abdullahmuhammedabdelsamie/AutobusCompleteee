export async function forward(request, env) {
  const url = new URL(request.url);
  const id = env.ROOMS.idFromName('autobus-global-game-state');
  const stub = env.ROOMS.get(id);
  return stub.fetch(new Request(url.toString(), request));
}
