أتوبيس كمبليت — نسخة Cloudflare Pages + Durable Objects
=======================================================

المشروع يحافظ على واجهة اللعبة وقواعدها، وينقل منطق السيرفر إلى Durable Object على Cloudflare.
يلزم نشر خدمتين على Cloudflare: خادم Durable Object، ثم مشروع Pages الذي يربط به.

1) نشر خادم الغرف (مرة واحدة)
- افتح مجلد backend على جهاز كمبيوتر عليه Node.js وnpm.
- من داخل مجلد backend شغّل: npm install
- سجّل دخولك: npx wrangler login
- من داخل مجلد backend شغّل: npx wrangler deploy
- انتظر نجاح النشر. اسم الـ Worker هو autobus-room-server.

2) نشر واجهة Pages
- ارفع محتويات مجلد pages إلى GitHub (index.html وfunctions وwrangler.toml) أو ارفعها إلى مستودع جديد.
- في Cloudflare Dashboard افتح Workers & Pages ثم Create application ثم Pages ثم Connect to Git.
- اختر المستودع، Framework preset: None، Build command اتركه فارغًا، Build output directory اكتب: .
- تأكد أن إعدادات wrangler.toml تُستخدم للمشروع وأن binding باسم ROOMS مرتبط بالـ Worker autobus-room-server.
- انشر المشروع.

مهم:
- Durable Objects تحتاج أن تكون متاحة في حساب Cloudflare وأن يُنشر Worker الخلفي أولًا.
- لا ترفع backend داخل مجلد Pages؛ انشره كـ Worker منفصل.
- الغرف تحفظ حالتها في Durable Object، لكن أي لاعب يغادر/تنقطع اتصالاته قد يظهر غيابه بحسب سلوك اللعبة.
- جرّب من نافذتين/جهازين وشبكتين مختلفتين قبل إرسال الرابط لأصدقائك.
